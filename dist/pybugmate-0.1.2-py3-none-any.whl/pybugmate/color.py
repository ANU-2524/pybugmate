def c_info(text):
    return f"\033[96m{text}\033[0m"   # Cyan

def c_return(text):
    return f"\033[92m{text}\033[0m"   # Green

def c_error(text):
    return f"\033[91m{text}\033[0m"   # Red

def c_profile(text):
    return f"\033[93m{text}\033[0m"   # Yellow
